/**
 * Hand-written types matching supabase/migrations/0001_initial_schema.sql
 * and 0002_public_debt_share.sql (which mirror claude/data-model-v1.md and
 * architecture-v1.md "The public debt-share link" in the project).
 *
 * TODO(Phase 0, once the Supabase project exists): replace this file with
 * the real generated types via `supabase gen types typescript` so it can
 * never drift from the actual database — this hand-written version is a
 * starting point for coding against before that project exists, not a
 * long-term source of truth.
 *
 * Row/Insert/Update types are each written out directly rather than derived
 * from `Database['public']['Tables'][...]` — matches what `supabase gen
 * types` itself emits, so switching to the real generated file later is a
 * drop-in swap rather than a restructure.
 *
 * IMPORTANT — see the @supabase/supabase-js version pin in package.json:
 * every published version from 2.56.0 through the current 2.112.4 has a
 * real regression where `supabase.rpc(name, args)` silently infers `args`
 * as `undefined` (a compile error on any real call) the moment the
 * Database type has both a Tables entry and a Functions entry — confirmed
 * by bisecting a minimal repro down to a single trivial table. 2.55.0 is
 * the last version before that broke. Don't bump this dependency without
 * re-testing `supabase.rpc(...)` against a schema with real Tables first.
 *
 * Fixed in the Phase 1 auth pass: every owner-scoped table (accounts,
 * categories, monthly_budgets, transactions, recurring_items,
 * long_term_items, debts) is `owner_id uuid not null` in the real schema
 * with no default/trigger — the client must always set it explicitly to
 * auth.uid(). The original hand-written Row types omitted `owner_id`
 * entirely, which silently made every insert here type-check while still
 * failing the real NOT NULL constraint at runtime. Now present on every
 * Row/Insert type below — don't drop it again when this file is eventually
 * replaced by `supabase gen types`.
 */

export type AccountType = 'BANK' | 'CASH' | 'SAVINGS' | 'RESERVE' | 'CARD';
export type CategoryType = 'EXPENSE' | 'INCOME';
export type TransactionType =
  | 'EXPENSE'
  | 'INCOME'
  | 'RESERVE_TRANSFER'
  | 'PAYMENT_FROM_RESERVE'
  | 'DEBT_SETTLEMENT_CREDIT';
export type TransactionStatus = 'PAID' | 'VOID';
/** MANUAL_PAYMENT added in 0014_manual_payments.sql — a one-off Payments →
 * ad-hoc payment confirmed paid, distinct from a plain Record-Expense
 * MANUAL entry (see lib/manual-payments.ts). */
export type TransactionSource =
  | 'MANUAL'
  | 'RECURRING'
  | 'LONG_TERM_QR'
  | 'DEBT_SETTLEMENT'
  | 'MANUAL_PAYMENT'
  /** Added in 0017_bank_inbox.sql — confirmed from the Bank inbox. */
  | 'BANK_IMPORT';
export type RecurringFrequency = 'MONTHLY' | 'YEARLY';
export type ReserveAmountMode = 'AUTO' | 'MANUAL';
/** MERGED added in 0011_debts_merge_supersede.sql — set on a debt that got
 * folded into another one via merge, instead of the row being deleted.
 * `merged_into_token` (below) says which debt replaced it. */
export type DebtStatus = 'OUTSTANDING' | 'CLAIMED_PAID' | 'SETTLED' | 'MERGED';
export type ThemeMode = 'light' | 'dark';

export interface Profile {
  id: string;
  default_account_id: string | null;
  month_start_day: number;
  amount_buttons: number[];
  /** Record Expense's quick-amount chip row — on by default, but Pavel can
   * turn it off entirely in Settings → Quick amounts rather than the row
   * always falling back to a default set. See migration 0008. */
  quick_amounts_enabled: boolean;
  notification_prefs: Record<string, unknown>;
  expo_push_token: string | null;
  theme: ThemeMode;
  language: 'en' | 'cs';
  /** ISO 4217 codes Settings → Currencies has been told to track/download
   * rates for — see supabase/migrations/0007_currencies.sql. */
  tracked_currencies: string[];
  /** Subset of tracked_currencies that shows up in Record Expense's
   * currency picker. CZK is never in either list — it's the implicit base. */
  active_currencies: string[];
  /** Record Expense's "recent inputs" list, below Save — on by default.
   * See migration 0012 and Settings → Recent inputs. */
  recent_inputs_enabled: boolean;
  /** 1–20, matching the schema's check constraint. */
  recent_inputs_count: number;
  /** 'all': last N entries overall. 'category': last N in whichever
   * category is currently selected on the form (falls back to 'all' for
   * Income, which has no category). */
  recent_inputs_scope: 'all' | 'category';
  /** Max characters shown for a row's category name in the recent-inputs
   * list before it's truncated with "…" — 3–24, see migration 0013. */
  recent_inputs_category_chars: number;
}
export type ProfileInsert = Partial<Profile> & Pick<Profile, 'id'>;
export type ProfileUpdate = Partial<Profile>;

export interface Account {
  id: string;
  owner_id: string;
  name: string;
  account_type: AccountType;
  account_prefix: string | null;
  account_number: string | null;
  bank_code: string | null;
  sort_order: number;
  active: boolean;
  created_at: string;
  /** 'FIO' = this account is watched via the Fio API (a token is stored
   * server-side — it is never readable from the app). Only ever set by the
   * set_fio_token RPC. See supabase/migrations/0016_fio_payments.sql. */
  bank_provider: 'FIO' | null;
  fio_last_checked_at: string | null;
  fio_last_success_at: string | null;
  fio_last_error: string | null;
  /** 'BANK_INBOX' = movements arrive from the bank into the Bank inbox
   * (needs bank_provider 'FIO'); 'MANUAL' = typed by hand. Migration 0017. */
  entry_mode: 'MANUAL' | 'BANK_INBOX';
  /** Never import movements booked before this day. */
  fio_sync_from: string | null;
  fio_synced_through: string | null;
  bank_sync_minutes: 10 | 15 | 60;
  bank_notify_push: boolean;
  bank_notify_daily: boolean;
  bank_last_digest_on: string | null;
  bank_last_push_at: string | null;
}
export type AccountInsert = Partial<Account> & Pick<Account, 'owner_id' | 'name' | 'account_type'>;
export type AccountUpdate = Partial<Account>;

export interface Category {
  id: string;
  owner_id: string;
  name: string;
  category_type: CategoryType;
  default_monthly_budget: number;
  sort_order: number;
  active: boolean;
}
export type CategoryInsert = Partial<Category> & Pick<Category, 'owner_id' | 'name' | 'category_type'>;
export type CategoryUpdate = Partial<Category>;

export interface MonthlyBudget {
  id: string;
  owner_id: string;
  budget_month: string; // 'yyyy-mm-01'
  category_id: string;
  planned_amount: number;
}
export type MonthlyBudgetInsert = Partial<MonthlyBudget> &
  Pick<MonthlyBudget, 'owner_id' | 'budget_month' | 'category_id' | 'planned_amount'>;
export type MonthlyBudgetUpdate = Partial<MonthlyBudget>;

export interface Transaction {
  id: string;
  owner_id: string;
  budget_month: string;
  transaction_date: string;
  type: TransactionType;
  category_id: string | null;
  account_id: string;
  amount: number;
  note: string | null;
  status: TransactionStatus;
  source: TransactionSource;
  receipt_photo_url: string | null;
  /** Set only on transactions generated by confirming a recurring-item
   * suggestion (source = 'RECURRING') — see supabase/migrations/
   * 0004_recurring_and_push.sql and lib/recurring.ts. */
  recurring_item_id: string | null;
  /** Set only on RESERVE_TRANSFER / PAYMENT_FROM_RESERVE transactions
   * generated from the monthly wizard's QR step (source = 'LONG_TERM_QR')
   * — see supabase/migrations/0005_long_term_links.sql and lib/long-term.ts. */
  long_term_item_id: string | null;
  /** Set only when this was entered in something other than CZK — `amount`
   * above is always the converted CZK figure; these three are purely
   * informational (see supabase/migrations/0007_currencies.sql and
   * lib/exchange-rates.ts). original_amount * exchange_rate === amount. */
  original_currency: string | null;
  original_amount: number | null;
  exchange_rate: number | null;
  /** Which event/trip this expense was tagged with, if any — see
   * supabase/migrations/0015_events.sql and claude/event-based-expenses-v1.md. */
  event_id: string | null;
  /** Fio movement this transaction was confirmed from / linked to (0017). */
  fio_movement_id: string | null;
  created_at: string;
  updated_at: string;
}
export type TransactionInsert = Partial<Transaction> &
  Pick<Transaction, 'owner_id' | 'budget_month' | 'transaction_date' | 'type' | 'account_id' | 'amount'>;
export type TransactionUpdate = Partial<Transaction>;

export interface RecurringItem {
  id: string;
  owner_id: string;
  name: string;
  category_id: string;
  account_id: string;
  amount: number;
  frequency: RecurringFrequency;
  day_of_month: number;
  active: boolean;
}
export type RecurringItemInsert = Partial<RecurringItem> &
  Pick<RecurringItem, 'owner_id' | 'name' | 'category_id' | 'account_id' | 'amount' | 'frequency' | 'day_of_month'>;
export type RecurringItemUpdate = Partial<RecurringItem>;

export interface LongTermItem {
  id: string;
  owner_id: string;
  name: string;
  category_id: string;
  full_payment_amount: number;
  payment_month: string;
  first_reserve_month: string;
  reserve_amount_mode: ReserveAmountMode;
  manual_monthly_reserve: number | null;
  opening_reserve_balance: number;
  repeat_yearly: boolean;
  reserve_account_id: string | null;
  target_account_prefix: string | null;
  target_account_number: string | null;
  target_bank_code: string | null;
  variable_symbol: string | null;
  constant_symbol: string | null;
  specific_symbol: string | null;
  payment_message: string | null;
  active: boolean;
}
export type LongTermItemInsert = Partial<LongTermItem> &
  Pick<LongTermItem, 'owner_id' | 'name' | 'category_id' | 'full_payment_amount' | 'payment_month' | 'first_reserve_month' | 'reserve_amount_mode'>;
export type LongTermItemUpdate = Partial<LongTermItem>;

/** Someone Pavel has paid via Payments → one-off payment — see migration
 * 0014 and lib/manual-payments.ts. Matched/reused by bank account, not by
 * name (findOrCreatePayee), so paying the same account again lands on the
 * same person instead of creating a duplicate. */
export interface Payee {
  id: string;
  owner_id: string;
  name: string;
  target_account_prefix: string | null;
  target_account_number: string;
  target_bank_code: string;
  last_paid_at: string | null;
  created_at: string;
}
export type PayeeInsert = Partial<Payee> &
  Pick<Payee, 'owner_id' | 'name' | 'target_account_number' | 'target_bank_code'>;
export type PayeeUpdate = Partial<Payee>;

/** A one-off payment still waiting to be confirmed paid. Deliberately no
 * "paid" state of its own — confirming deletes this row and posts a real
 * `transactions` row instead (source MANUAL_PAYMENT), which is the
 * permanent record from then on. */
export interface ManualPayment {
  id: string;
  owner_id: string;
  payee_id: string;
  category_id: string;
  account_id: string;
  amount: number;
  message: string | null;
  variable_symbol: string | null;
  created_at: string;
}
export type ManualPaymentInsert = Partial<ManualPayment> &
  Pick<ManualPayment, 'owner_id' | 'payee_id' | 'category_id' | 'account_id' | 'amount'>;
export type ManualPaymentUpdate = Partial<ManualPayment>;

/** Snapshot of one debt row folded into a merged debt — enough to
 * recreate that row exactly if the merge is later undone via "Unmerge" on
 * the Debts page. See supabase/migrations/0010_debts_unmerge_support.sql
 * and lib/debt-merge.ts's buildMergedFromSnapshot(). */
export interface MergedDebtSnapshot {
  owed_by_name: string;
  amount: number;
  message: string | null;
  transaction_id: string | null;
  target_account_id: string;
  /** Set only if this source row was itself already a merged debt at the
   * time it was folded into the new one — preserves that history so
   * unmerging, then unmerging again, still recovers every original
   * rather than losing a level. */
  merged_from: MergedDebtSnapshot[] | null;
}

export interface Debt {
  id: string;
  owner_id: string;
  /** Null for a debt created by merging others (supabase/migrations/
   * 0009_debts_merge_support.sql) — it may combine debts from different
   * original transactions/categories, so it deliberately doesn't point at
   * any single one of them rather than misattributing the total. */
  transaction_id: string | null;
  owed_by_name: string;
  amount: number;
  target_account_id: string;
  status: DebtStatus;
  share_token: string;
  /** Set only when status is MERGED — the share_token of the debt this one
   * was folded into. The public share page follows this (through however
   * many hops) to send a visitor holding a superseded link to the current
   * one instead of a dead end. See supabase/migrations/
   * 0011_debts_merge_supersede.sql. */
  merged_into_token: string | null;
  /** Shown on the public share link / used as the QR payment message —
   * see supabase/migrations/0003_debt_message.sql. Falls back to the
   * linked transaction's own note, then the category name, when unset. */
  message: string | null;
  claimed_paid_at: string | null;
  settled_at: string | null;
  settlement_transaction_id: string | null;
  created_at: string;
  /** Set only on a debt created by "Merge" (Debts page) or the "merge
   * with an existing outstanding debt" offer at save time — a snapshot of
   * what was folded in, so "Unmerge" can recreate the originals. Null for
   * an ordinary, never-merged debt. See supabase/migrations/
   * 0010_debts_unmerge_support.sql. */
  merged_from: MergedDebtSnapshot[] | null;
  /** Set on a "Split this event" debt (transaction_id null, same reasoning
   * as a merge) so it can still say which trip it came from. See
   * supabase/migrations/0015_events.sql. */
  event_id: string | null;
  /** Unique variable symbol put in the QR / shown for manual payment, used
   * to match Fio payments. See 0016_fio_payments.sql. */
  payment_vs: string;
  /** Set when the debt belongs to a one-link group bill (0019_group_bills.sql). */
  group_id: string | null;
  /** 'FIO' when the debt was settled automatically from the bank feed. */
  settled_via: 'FIO' | null;
  fio_movement_id: string | null;
}
export type DebtInsert = Partial<Debt> &
  Pick<Debt, 'owner_id' | 'owed_by_name' | 'amount' | 'target_account_id'>;
export type DebtUpdate = Partial<Debt>;

/** A tagged period/trip (Pavel: "Weekend in Cracow") — see
 * supabase/migrations/0015_events.sql and claude/event-based-expenses-v1.md.
 * Deactivating (not deleting) is what stops it being offered as a badge
 * option in Record Expense while keeping every transaction tagged with it
 * filterable forever, same convention as categories/accounts `active`. */
export interface EventRow {
  id: string;
  owner_id: string;
  name: string;
  active: boolean;
  created_at: string;
}
export type EventInsert = Partial<EventRow> & Pick<EventRow, 'owner_id' | 'name'>;
export type EventUpdate = Partial<EventRow>;

/** One bill shared through a single link (0019_group_bills.sql). */
export interface DebtGroup {
  id: string;
  owner_id: string;
  target_account_id: string;
  mode: 'ONE_QR' | 'PER_PERSON';
  message: string | null;
  per_person: number | null;
  group_vs: string;
  share_token: string;
  created_at: string;
}
export type DebtGroupInsert = Partial<DebtGroup> & Pick<DebtGroup, 'owner_id' | 'target_account_id' | 'mode'>;
export type DebtGroupUpdate = Partial<DebtGroup>;

/** What get_group_by_share_token returns (null for an unknown token). */
export interface GroupShareView {
  mode: 'ONE_QR' | 'PER_PERSON';
  description: string;
  per_person: number | null;
  target_account_prefix: string | null;
  target_account_number: string | null;
  target_bank_code: string | null;
  fio_enabled: boolean;
  variable_symbol: string | null;
  members: { name: string; amount: number; token: string; status: DebtStatus; automatic: boolean }[];
}

export type BankKind = 'EXPENSE' | 'INCOME' | 'TRANSFER' | 'CASH';
export type BankStatus = 'NEW' | 'POSTED' | 'LINKED' | 'TRANSFER' | 'IGNORED' | 'DEBT';

/** One movement from the bank feed, waiting in (or already decided from) the
 * Bank inbox — migration 0017. Read-only for the app: changes go through the
 * bank_post / bank_link / bank_decide functions. Amount is signed (negative =
 * money out). */
export interface BankTransaction {
  id: string;
  owner_id: string;
  account_id: string;
  movement_id: string;
  booked_date: string;
  amount: number;
  merchant: string;
  merchant_key: string;
  counter_account: string | null;
  counter_bank: string | null;
  movement_type: string | null;
  details: string | null;
  vs: string | null;
  kind: BankKind;
  suggested_category_id: string | null;
  suggested_uses: number | null;
  /** The other own account for a TRANSFER, the Cash account for CASH. */
  suggested_account_id: string | null;
  recurring_item_id: string | null;
  match_transaction_id: string | null;
  status: BankStatus;
  transaction_id: string | null;
  to_account_id: string | null;
  matched_debt_id: string | null;
  created_at: string;
}

/** Remembered merchant -> category, learned when an inbox item is saved. */
export interface BankRule {
  id: string;
  owner_id: string;
  match_key: string;
  category_id: string;
  uses: number;
  updated_at: string;
}
export type BankRuleInsert = Partial<BankRule> & Pick<BankRule, 'owner_id' | 'match_key' | 'category_id'>;
export type BankRuleUpdate = Partial<BankRule>;

/** A browser/device that has granted Web Push permission — see
 * supabase/migrations/0004_recurring_and_push.sql and lib/push.ts. Mirrors
 * the standard PushSubscription shape (endpoint + the two encryption keys
 * from subscription.toJSON().keys). */
export interface PushSubscriptionRow {
  id: string;
  owner_id: string;
  endpoint: string;
  p256dh: string;
  auth: string;
  created_at: string;
}
export type PushSubscriptionInsert = Partial<PushSubscriptionRow> &
  Pick<PushSubscriptionRow, 'owner_id' | 'endpoint' | 'p256dh' | 'auth'>;
export type PushSubscriptionUpdate = Partial<PushSubscriptionRow>;

/** A cached ČNB daily fixing rate — see supabase/migrations/
 * 0007_currencies.sql and lib/exchange-rates.ts. `rate` is CZK per
 * `amount_unit` units of `currency_code` (some currencies, e.g. HUF, are
 * quoted per 100 rather than per 1). Not owner-scoped — shared/global. */
export interface ExchangeRateRow {
  currency_code: string;
  rate_date: string; // 'yyyy-mm-dd', always a day ČNB actually published
  amount_unit: number;
  rate: number;
  fetched_at: string;
}
export type ExchangeRateInsert = Partial<ExchangeRateRow> &
  Pick<ExchangeRateRow, 'currency_code' | 'rate_date' | 'rate'>;
export type ExchangeRateUpdate = Partial<ExchangeRateRow>;

/** Shape returned by the public `get_debt_by_share_token` RPC — see 0002
 * and, for the MERGED case, 0011_debts_merge_supersede.sql. When status is
 * MERGED, every payment field is null (a superseded link never reveals the
 * replacement's payment details) and `merged_into_token` — already resolved
 * through however many merge hops — is the current token to send the
 * visitor to next, or null if that chain dead-ends (the replacement was
 * itself since deleted). */
export interface DebtShareView {
  description: string | null;
  amount: number | null;
  status: DebtStatus;
  target_account_prefix: string | null;
  target_account_number: string | null;
  target_bank_code: string | null;
  merged_into_token: string | null;
}

export interface Database {
  // Required by @supabase/supabase-js's type-inference so it knows which
  // PostgREST version's rpc()/query typing rules to apply — matches what
  // `supabase gen types typescript` emits automatically once the real
  // Supabase project exists (see the TODO at the top of this file).
  __InternalSupabase: {
    PostgrestVersion: '13';
  };
  public: {
    Views: {};
    Tables: {
      profile: { Row: Profile; Insert: ProfileInsert; Update: ProfileUpdate };
      accounts: { Row: Account; Insert: AccountInsert; Update: AccountUpdate };
      categories: { Row: Category; Insert: CategoryInsert; Update: CategoryUpdate };
      monthly_budgets: { Row: MonthlyBudget; Insert: MonthlyBudgetInsert; Update: MonthlyBudgetUpdate };
      transactions: { Row: Transaction; Insert: TransactionInsert; Update: TransactionUpdate };
      recurring_items: { Row: RecurringItem; Insert: RecurringItemInsert; Update: RecurringItemUpdate };
      long_term_items: { Row: LongTermItem; Insert: LongTermItemInsert; Update: LongTermItemUpdate };
      debts: { Row: Debt; Insert: DebtInsert; Update: DebtUpdate };
      debt_groups: { Row: DebtGroup; Insert: DebtGroupInsert; Update: DebtGroupUpdate };
      events: { Row: EventRow; Insert: EventInsert; Update: EventUpdate };
      bank_transactions: { Row: BankTransaction; Insert: never; Update: never };
      bank_rules: { Row: BankRule; Insert: BankRuleInsert; Update: BankRuleUpdate };
      push_subscriptions: {
        Row: PushSubscriptionRow;
        Insert: PushSubscriptionInsert;
        Update: PushSubscriptionUpdate;
      };
      exchange_rates: {
        Row: ExchangeRateRow;
        Insert: ExchangeRateInsert;
        Update: ExchangeRateUpdate;
      };
    };
    Functions: {
      // From supabase/migrations/0002_public_debt_share.sql — the narrow,
      // no-login RPCs the public /d/[token] page is allowed to call.
      get_debt_by_share_token: {
        Args: { p_token: string };
        Returns: DebtShareView[];
      };
      get_group_by_share_token: {
        Args: { p_token: string };
        Returns: GroupShareView | null;
      };
      claim_debt_paid: {
        Args: { p_token: string };
        Returns: void;
      };
      undo_claim_debt_paid: {
        Args: { p_token: string };
        Returns: void;
      };
      // From supabase/migrations/0017_bank_inbox.sql — the only way the app
      // changes a bank_transactions row.
      bank_post: {
        Args: { p_id: string; p_category_id: string | null; p_event_id: string | null; p_note: string | null };
        Returns: string;
      };
      bank_link: {
        Args: { p_id: string; p_transaction_id: string };
        Returns: void;
      };
      bank_decide: {
        Args: { p_id: string; p_status: 'IGNORED' | 'TRANSFER' | 'NEW'; p_to_account: string | null };
        Returns: void;
      };
    };
  };
}
