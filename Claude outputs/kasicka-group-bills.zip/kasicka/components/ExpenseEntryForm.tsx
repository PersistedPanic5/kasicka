import { createElement, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Image, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useTheme } from '@/lib/theme-context';
import { fontFamily } from '@/lib/theme';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth-context';
import { useAppData } from '@/lib/use-app-data';
import { useLanguage } from '@/lib/language-context';
import { budgetMonthForDate } from '@/lib/budget-month';
import { categoryColor } from '@/lib/identity';
import { LogoMark } from '@/components/Logo';
import { ensureRate, toCzk, type ResolvedRate } from '@/lib/exchange-rates';
import {
  createOrMergeDebtsForSplit,
  emptySplitPerson,
  newSplitPersonId,
  splitEvenly,
  splitPeopleSum,
  useDebtHistory,
  validSplitPeople,
  type OutstandingDebtMatch,
  type SplitPerson,
} from '@/lib/split-people';
import { NameAutocompleteInput } from '@/components/NameAutocompleteInput';
import { ShareModePicker } from '@/components/ShareModePicker';
import { createGroupDebts, groupLink, groupProblem, type ShareMode } from '@/lib/debt-groups';

/** One split person's name matching an existing outstanding debt, offered
 * for merging at Save time — see the mergeOffer state below and
 * lib/split-people.ts's createOrMergeDebtsForSplit. */
interface MergeOfferMatch {
  name: string;
  newAmount: number;
  existing: OutstandingDebtMatch;
}

/** One row of the "recent inputs" list below Save (Pavel: "not sure what
 * exactly have I already input") — just enough to render one lightweight
 * line, not a full Transaction. */
interface RecentInputRow {
  id: string;
  amount: number;
  type: 'EXPENSE' | 'INCOME';
  note: string | null;
  category_id: string | null;
  transaction_date: string;
}

const WEEKDAY_SHORT_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const WEEKDAY_SHORT_CS = ['Ne', 'Po', 'Út', 'St', 'Čt', 'Pá', 'So'];
const MONTH_SHORT_EN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/** "Wed 3 Sep" / "St 3. 9." — the short weekday+date shown in brackets next
 * to Today/Tomorrow/±N days (Pavel's request), so the day shifter is never
 * ambiguous about which actual date it landed on. */
function formatShortDate(iso: string, language: 'en' | 'cs'): string {
  const d = new Date(`${iso}T00:00:00`);
  const weekday = language === 'cs' ? WEEKDAY_SHORT_CS[d.getDay()] : WEEKDAY_SHORT_EN[d.getDay()];
  const day = d.getDate();
  return language === 'cs' ? `${weekday} ${day}. ${d.getMonth() + 1}.` : `${weekday} ${day} ${MONTH_SHORT_EN[d.getMonth()]}`;
}

/** Shortens a category name for the recent-inputs list — Pavel: "shorten
 * it to 8 signs or something like that", configurable in Settings →
 * Recent inputs. Plain character-count truncation (not numberOfLines'
 * layout-based ellipsis) since this sits in a fixed-width row next to the
 * amount and date, which a long name would otherwise push off. */
function truncateCategoryName(name: string, maxChars: number): string {
  return name.length > maxChars ? `${name.slice(0, maxChars)}…` : name;
}

/**
 * The fast expense-capture form — the single most important screen in the
 * app (see screens-and-flows.md "Core UX principle"). Used both by the
 * mobile fast-entry screen (compact) and the desktop Home tab (roomier),
 * via the `variant` prop, so the core action never has two implementations
 * to keep in sync.
 *
 * Phase 1: real save, a note field, plus the "split part of this with
 * someone" debt panel (debts-ledger-requirements.md "Mechanism") — the
 * full transaction amount is always what actually left your account and
 * counts as spend; the split amount just additionally creates a `debts`
 * row against the same transaction, pointing at the debtor's own
 * shareable link (app/d/[token].tsx). The note travels two ways: it's
 * shown as the transaction's own label (app/(app)/transactions.tsx), and
 * — via get_debt_by_share_token's fallback order (see
 * supabase/migrations/0003_debt_message.sql) — becomes the debt's public
 * description/QR message too, unless the split panel's own "message"
 * field overrides it for that debt specifically. account_id/category_id
 * come from useAppData (the signed-in user's bootstrap-created default
 * account + expense categories — see lib/bootstrap.ts).
 *
 * The collapsed "more options" panel (account/photo) — the last piece of
 * Phase 1, per build-roadmap-v1.md — is a single toggle revealing: an
 * account pill-switcher (defaults to profile.default_account_id, same as
 * before, just now overridable per-entry) and a receipt photo capture.
 * Photo capture is web-only for now (a plain hidden <input type="file"
 * capture="environment"> — the standard way to hit the phone camera from a
 * PWA without a native module); a native picker (expo-image-picker) is a
 * follow-up once a real native build exists, matching the PWA-first
 * decision in architecture-v1.md. The file uploads straight to the private
 * "receipts" Supabase Storage bucket (supabase/migrations/
 * 0004_recurring_and_push.sql) under a <user_id>/<filename> path, and the
 * returned storage *path* (not a public URL — the bucket isn't public) is
 * what's saved to transactions.receipt_photo_url; viewing it later means
 * generating a signed URL from that path.
 */
export function ExpenseEntryForm({ variant = 'mobile' }: { variant?: 'mobile' | 'desktop' }) {
  const { tokens } = useTheme();
  const { t, language } = useLanguage();
  const { user } = useAuth();
  const {
    defaultAccountId,
    categories,
    accounts,
    monthStartDay,
    amountButtons,
    quickAmountsEnabled,
    activeCurrencies,
    activeEvents,
    recentInputsEnabled,
    recentInputsCount,
    recentInputsScope,
    recentInputsCategoryChars,
    loading: dataLoading,
  } = useAppData();

  const [entryType, setEntryType] = useState<'EXPENSE' | 'INCOME'>('EXPENSE');
  const [amount, setAmount] = useState('');
  const [categoryId, setCategoryId] = useState<string | null>(null);
  const [dayOffset, setDayOffset] = useState(0);
  const [note, setNote] = useState('');

  // ── Event badge (claude/event-based-expenses-v1.md) ─────────────────
  const [eventId, setEventId] = useState<string | null>(null);

  // Defaults a fresh form to the newest active event (so the common case —
  // one trip happening right now — needs zero taps) and clears the
  // selection if it's no longer a valid active event (none active yet, or
  // Settings deactivated the one that was picked).
  useEffect(() => {
    if (activeEvents.length === 0) {
      if (eventId !== null) setEventId(null);
      return;
    }
    if (!eventId || !activeEvents.some((e) => e.id === eventId)) {
      setEventId(activeEvents[0].id);
    }
    // eventId intentionally omitted — this only needs to react to the
    // active-events list changing, not to the cycle below re-setting it.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeEvents]);

  // Cycles every active event (newest first) → off → back around (Pavel:
  // "event → off → other possible event"), same tap-to-cycle interaction
  // as the currency badge.
  function cycleEvent() {
    const list: (string | null)[] = [...activeEvents.map((e) => e.id), null];
    const idx = list.indexOf(eventId);
    setEventId(list[(idx + 1) % list.length]);
  }

  // ── Currency (Pavel's request) ──────────────────────────────────────
  const [currency, setCurrency] = useState('CZK');
  const [rateInfo, setRateInfo] = useState<ResolvedRate | null>(null);
  const [rateLoading, setRateLoading] = useState(false);
  const [rateError, setRateError] = useState<string | null>(null);

  // ── Split with someone(s) (Pavel's multi-person rebuild) ────────────
  const [splitEnabled, setSplitEnabled] = useState(false);
  const [splitTotalAmount, setSplitTotalAmount] = useState('');
  const [splitMessage, setSplitMessage] = useState('');
  const [shareMode, setShareMode] = useState<ShareMode>('INDIVIDUAL');
  const [splitPeople, setSplitPeople] = useState<SplitPerson[]>([emptySplitPerson()]);
  const debtHistory = useDebtHistory();
  // Pavel: "if I select the already existing person - offer me to merge
  // when confirming" — set only while the confirmation modal below is
  // open; `chosen` is the set of (trimmed, lowercased) names currently
  // opted into merging, defaulting to "merge all" when the offer appears.
  const [mergeOffer, setMergeOffer] = useState<{ matches: MergeOfferMatch[]; chosen: Set<string> } | null>(null);

  const [saving, setSaving] = useState(false);
  const [savedFlash, setSavedFlash] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [shareLinks, setShareLinks] = useState<{ name: string; link: string }[]>([]);
  const [copiedLinkIdx, setCopiedLinkIdx] = useState<number | null>(null);

  // ── Recent inputs (Settings → Recent inputs) ────────────────────────
  const [recentInputs, setRecentInputs] = useState<RecentInputRow[]>([]);

  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const [photoPath, setPhotoPath] = useState<string | null>(null);
  const [photoPreviewUrl, setPhotoPreviewUrl] = useState<string | null>(null);
  const [photoUploading, setPhotoUploading] = useState(false);
  const [photoError, setPhotoError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Categories load asynchronously right after sign-in (first-run
  // bootstrap creates them) — default to the first one once they arrive.
  const activeCategoryId = categoryId ?? categories[0]?.id ?? null;
  const activeAccountId = selectedAccountId ?? defaultAccountId;

  // Category scoping only makes sense for EXPENSE (INCOME has no category)
  // — falls back to the last N overall in that case, rather than the list
  // just going empty on the Income tab.
  const recentInputsCategoryFilter =
    recentInputsScope === 'category' && entryType === 'EXPENSE' ? activeCategoryId : null;

  const loadRecentInputs = useCallback(async () => {
    if (!user || !recentInputsEnabled) {
      setRecentInputs([]);
      return;
    }
    // source in (MANUAL, MANUAL_PAYMENT) — entries actually typed in
    // somewhere by hand (here, Transactions' own "add", or confirming a
    // Payments → one-off payment), not recurring/long-term auto-generated
    // rows, which isn't what Pavel meant by "what have I already input".
    let query = supabase
      .from('transactions')
      .select('id, amount, type, note, category_id, transaction_date')
      .eq('owner_id', user.id)
      .eq('status', 'PAID')
      .in('source', ['MANUAL', 'MANUAL_PAYMENT'])
      .order('created_at', { ascending: false })
      .limit(recentInputsCount);
    if (recentInputsCategoryFilter) query = query.eq('category_id', recentInputsCategoryFilter);
    const { data } = await query;
    setRecentInputs((data as RecentInputRow[] | null) ?? []);
  }, [user, recentInputsEnabled, recentInputsCount, recentInputsCategoryFilter]);

  useEffect(() => {
    loadRecentInputs();
  }, [loadRecentInputs]);

  // profile.amount_buttons, editable in Settings → Quick amounts — falls
  // back to the schema default if it's ever empty (e.g. mid-edit there).
  // The whole row can also be turned off entirely there
  // (quickAmountsEnabled) rather than relying on that fallback for "none".
  const quickAmounts = amountButtons.length > 0 ? amountButtons : [20, 50, 100, 200];

  function shiftedDateISO(offset: number) {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return d.toISOString().slice(0, 10);
  }

  const transactionDateISO = useMemo(() => shiftedDateISO(dayOffset), [dayOffset]);

  const dateLabel = useMemo(() => {
    const short = formatShortDate(transactionDateISO, language);
    if (dayOffset === 0) return `${t('common.today')} (${short})`;
    if (dayOffset === 1) return `${t('common.tomorrow')} (${short})`;
    if (dayOffset === -1) return `${t('common.yesterday')} (${short})`;
    const n = dayOffset > 0 ? `+${dayOffset} ${t('common.days')}` : `${dayOffset} ${t('common.days')}`;
    return `${n} (${short})`;
  }, [dayOffset, transactionDateISO, language, t]);

  // Cycles CZK → each active currency → back to CZK (Pavel's answer: CZK
  // stays part of the cycle, one control does everything). Tapping the
  // small currency badge next to the amount calls this.
  function cycleCurrency() {
    const list = ['CZK', ...activeCurrencies];
    const idx = list.indexOf(currency);
    setCurrency(list[(idx + 1) % list.length]);
  }

  // Fetches (cache-first — see lib/exchange-rates.ts) the rate for the
  // selected currency/date whenever either changes, NOT on every keystroke
  // of the amount itself — the rate doesn't depend on how much was typed,
  // only on which currency and which day. A cache miss triggers a real
  // ČNB call in the background (via the fetch-exchange-rate Edge
  // Function) and gets stored for next time, per Pavel's "if this
  // particular day is not downloaded yet, it should be downloaded in
  // background and saved to the database."
  useEffect(() => {
    if (currency === 'CZK') {
      setRateInfo(null);
      setRateError(null);
      return;
    }
    let cancelled = false;
    setRateLoading(true);
    setRateError(null);
    ensureRate(currency, transactionDateISO).then(({ rate, error }) => {
      if (cancelled) return;
      setRateLoading(false);
      if (error) {
        setRateError(error);
        setRateInfo(null);
      } else {
        setRateInfo(rate);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [currency, transactionDateISO]);

  // Live CZK-equivalent preview shown next to the amount input — recomputes
  // on every keystroke from the already-fetched rate, no extra network call.
  const czkEquivalent = useMemo(() => {
    if (currency === 'CZK' || !rateInfo) return null;
    const numeric = Number(amount);
    if (!Number.isFinite(numeric) || numeric <= 0) return null;
    return toCzk(numeric, rateInfo);
  }, [currency, rateInfo, amount]);

  function linkForToken(token: string) {
    if (Platform.OS === 'web' && typeof window !== 'undefined') {
      return `${window.location.origin}/d/${token}`;
    }
    return `/d/${token}`;
  }

  function triggerPhotoPicker() {
    fileInputRef.current?.click();
  }

  function clearPhoto() {
    setPhotoPath(null);
    setPhotoPreviewUrl(null);
    setPhotoError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  }

  async function handlePhotoChange(e: { target: { files: FileList | null } }) {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    setPhotoError(null);
    setPhotoUploading(true);
    const ext = file.name.includes('.') ? file.name.split('.').pop() : 'jpg';
    const path = `${user.id}/${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from('receipts').upload(path, file, {
      contentType: file.type || 'image/jpeg',
    });
    if (error) {
      setPhotoError(error.message);
      setPhotoUploading(false);
      return;
    }
    setPhotoPath(path);
    setPhotoPreviewUrl(URL.createObjectURL(file));
    setPhotoUploading(false);
  }

  // ── Split-people helpers (multi-person rebuild) ─────────────────────
  const splitSum = useMemo(() => splitPeopleSum(splitPeople), [splitPeople]);
  const splitTotalNumeric = Number(splitTotalAmount) || 0;
  const splitRemaining = Math.round((splitTotalNumeric - splitSum) * 100) / 100;

  function addSplitPerson() {
    setSplitPeople((prev) => [...prev, emptySplitPerson()]);
  }
  function removeSplitPerson(id: string) {
    setSplitPeople((prev) => (prev.length <= 1 ? prev : prev.filter((p) => p.id !== id)));
  }
  function updateSplitPerson(id: string, field: 'name' | 'amount', value: string) {
    setSplitPeople((prev) => prev.map((p) => (p.id === id ? { ...p, [field]: value } : p)));
  }
  /** Divides splitTotalAmount evenly across the current people list —
   * re-pressable any time the total or the people list changes, since it's
   * a pure recompute from whatever's currently in those two, not something
   * that accumulates. */
  function handleSplitEvenly() {
    setSplitPeople((prev) => splitEvenly(splitTotalNumeric, prev));
  }
  function resetSplitState() {
    setSplitEnabled(false);
    setSplitTotalAmount('');
    setSplitMessage('');
    setShareMode('INDIVIDUAL');
    setSplitPeople([emptySplitPerson()]);
  }

  /** Sets (rather than toggles) one match's merge choice — Pavel: tapping
   * "Merge" while it's already selected should stay selected, not flip
   * back to "Keep separate". Each button always sets its own outcome
   * explicitly instead of both buttons toggling the same boolean. */
  function setMergeChoice(key: string, shouldMerge: boolean) {
    setMergeOffer((prev) => {
      if (!prev) return prev;
      const next = new Set(prev.chosen);
      if (shouldMerge) next.add(key);
      else next.delete(key);
      return { ...prev, chosen: next };
    });
  }

  /** `offer` is only ever passed back in from the merge-offer modal's
   * "Continue" button below — a plain Save press always calls this with
   * no argument, so a fresh match-check runs every time. */
  async function handleSave(offer?: { matches: MergeOfferMatch[]; chosen: Set<string> }) {
    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) return;

    const isExpense = entryType === 'EXPENSE';
    if (!user || !activeAccountId || (isExpense && !activeCategoryId)) {
      setErrorMsg(t('home.settingUpAccount'));
      return;
    }

    // A foreign currency needs its rate resolved before there's a CZK
    // amount to save at all — ensureRate() already kicked off the fetch
    // as soon as the currency was picked (see the effect above), so this
    // is normally instant; it only blocks Save while that first fetch for
    // a brand-new date/currency pair is genuinely still in flight.
    if (currency !== 'CZK') {
      if (rateLoading) {
        setErrorMsg(t('home.rateFetching'));
        return;
      }
      if (rateError || !rateInfo) {
        setErrorMsg(`${t('home.rateErrorPrefix')} ${rateError ?? ''}`);
        return;
      }
    }
    const czkAmount = currency !== 'CZK' && rateInfo ? toCzk(numericAmount, rateInfo) : numericAmount;

    const validPeople = validSplitPeople(splitPeople);
    const splitting = isExpense && splitEnabled && validPeople.length > 0 && splitTotalNumeric > 0;
    if (splitting && splitTotalNumeric > czkAmount) {
      setErrorMsg(t('home.splitTooBig'));
      return;
    }
    if (splitting && splitSum > splitTotalNumeric + 0.01) {
      setErrorMsg(t('home.splitOverAllocatedError'));
      return;
    }

    const grouped = splitting && shareMode !== 'INDIVIDUAL';
    const problem = grouped ? groupProblem(shareMode, validPeople) : null;
    if (problem) {
      setErrorMsg(t(problem));
      return;
    }

    // Before actually saving anything, check whether any split person
    // matches someone who already has an outstanding debt — if so, pause
    // for confirmation instead of silently creating yet another separate
    // debt/link for them (Pavel's whole complaint: "suddenly I have one
    // person with like 3 bills"). `offer` is only set when re-entering
    // from that modal's "Continue", so this never re-prompts for the same
    // save attempt.
    if (splitting && !grouped && !offer) {
      const matches = validPeople
        .map((p): MergeOfferMatch | null => {
          const existing = debtHistory.outstandingByName.get(p.name.trim().toLowerCase());
          return existing ? { name: p.name, newAmount: p.amount, existing } : null;
        })
        .filter((m): m is MergeOfferMatch => m !== null);
      if (matches.length > 0) {
        setMergeOffer({ matches, chosen: new Set(matches.map((m) => m.name.trim().toLowerCase())) });
        return;
      }
    }

    setSaving(true);
    setErrorMsg(null);
    setShareLinks([]);

    const transactionDate = transactionDateISO;
    // month_start_day-aware — see lib/budget-month.ts. Defaults to plain
    // calendar months until Settings → Profile & preferences sets it.
    const budgetMonth = budgetMonthForDate(transactionDate, monthStartDay);

    const { data: transaction, error } = await supabase
      .from('transactions')
      .insert({
        owner_id: user.id,
        budget_month: budgetMonth,
        transaction_date: transactionDate,
        type: entryType,
        account_id: activeAccountId,
        // Income isn't categorized (no Categories UI creates INCOME-type
        // categories yet — build-roadmap-v1.md Phase 4) — category_id is
        // nullable on transactions for exactly this.
        category_id: isExpense ? activeCategoryId : null,
        amount: czkAmount,
        note: note.trim() || null,
        event_id: isExpense ? eventId : null,
        receipt_photo_url: photoPath,
        original_currency: currency !== 'CZK' ? currency : null,
        original_amount: currency !== 'CZK' ? numericAmount : null,
        exchange_rate: currency !== 'CZK' && rateInfo ? rateInfo.rate / rateInfo.amountUnit : null,
      })
      .select('id')
      .single();

    if (error || !transaction) {
      setErrorMsg(error?.message ?? t('common.savingError'));
      setSaving(false);
      return;
    }

    if (splitting && grouped) {
      const g = await createGroupDebts({
        ownerId: user.id,
        transactionId: transaction.id,
        eventId,
        targetAccountId: activeAccountId,
        message: splitMessage.trim() || null,
        mode: shareMode as 'ONE_QR' | 'PER_PERSON',
        people: validPeople,
      });
      if (g.error) setErrorMsg(`${t('common.shareLinkFailedPrefix')} ${g.error}`);
      if (g.groupToken) setShareLinks([{ name: t('home.groupLinkName'), link: groupLink(g.groupToken) }]);
    } else if (splitting) {
      // Created one by one (see lib/split-people.ts) — the expense itself
      // is already saved either way, so a partial failure here surfaces an
      // error without rolling anything back. A person opted into merging
      // (offer?.chosen) folds into their existing outstanding debt instead
      // of getting a new one — see createOrMergeDebtsForSplit.
      const { links, error: splitError } = await createOrMergeDebtsForSplit({
        ownerId: user.id,
        transactionId: transaction.id,
        eventId,
        targetAccountId: activeAccountId,
        message: splitMessage.trim() || null,
        people: validPeople,
        outstandingByName: debtHistory.outstandingByName,
        mergeNames: offer?.chosen ?? new Set(),
        currencyLabel: t('common.czk'),
      });
      if (splitError) setErrorMsg(`${t('common.shareLinkFailedPrefix')} ${splitError}`);
      setShareLinks(links.map((l) => ({ name: l.name, link: linkForToken(l.token) })));
    }

    setSavedFlash(true);
    setTimeout(() => setSavedFlash(false), 1200);
    loadRecentInputs();
    setEntryType('EXPENSE');
    setAmount('');
    setNote('');
    setCurrency('CZK');
    resetSplitState();
    setMergeOffer(null);
    setCopiedLinkIdx(null);
    setSelectedAccountId(null);
    clearPhoto();
    setSaving(false);
  }

  async function copyShareLink(idx: number) {
    const link = shareLinks[idx];
    if (!link) return;
    if (Platform.OS === 'web' && typeof navigator !== 'undefined' && navigator.clipboard) {
      await navigator.clipboard.writeText(link.link);
      setCopiedLinkIdx(idx);
      setTimeout(() => setCopiedLinkIdx(null), 1500);
    }
  }

  return (
    <View style={[styles.container, variant === 'desktop' && styles.containerDesktop]}>
      <View style={[styles.typeToggle, { backgroundColor: tokens.card }]}>
        {(['EXPENSE', 'INCOME'] as const).map((type) => {
          const active = entryType === type;
          return (
            <Pressable
              key={type}
              onPress={() => setEntryType(type)}
              style={[styles.typeToggleBtn, { backgroundColor: active ? tokens.accent : 'transparent' }]}
            >
              <Text
                style={{
                  color: active ? tokens.accentText : tokens.textMuted,
                  fontFamily: fontFamily.semibold,
                  fontSize: 13,
                }}
              >
                {type === 'EXPENSE' ? t('home.entryTypeExpense') : t('home.entryTypeIncome')}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View style={styles.dateRow}>
        <Pressable
          onPress={() => setDayOffset((d) => d - 1)}
          style={[styles.dateShiftBtn, { backgroundColor: tokens.card }]}
        >
          <Text style={{ color: tokens.text, fontFamily: fontFamily.bold }}>−</Text>
        </Pressable>
        <Text style={{ color: tokens.text, fontFamily: fontFamily.semibold, minWidth: 130, textAlign: 'center' }}>
          {dateLabel}
        </Text>
        <Pressable
          onPress={() => setDayOffset((d) => d + 1)}
          style={[styles.dateShiftBtn, { backgroundColor: tokens.card }]}
        >
          <Text style={{ color: tokens.text, fontFamily: fontFamily.bold }}>+</Text>
        </Pressable>
      </View>

      {/* Faint piggy-bank watermark behind the amount — design refresh
          (2026-09): reinforces the Kasička mark at the one moment this
          screen is most "yours" without competing with the actual number,
          which still sits on the plain background in front of it. Holes
          drawn in the same color as the body so at this opacity they read
          as part of one flat silhouette rather than distracting cutouts.
          Wrapped with the amount row (not the whole form) and absolutely
          filled + centered within just that wrapper, so it sits right
          behind the number regardless of how tall the rest of the form is. */}
      <View style={styles.amountWrap}>
        <View style={styles.watermarkWrap} pointerEvents="none">
          {/* Sized to match Main.dc.html's mockup exactly, not a rounder
              guess: the mockup's watermark is 272px wide in a 390px-wide
              frame (≈70% of the column) — LogoMark's `size` prop sets
              height, so 272 / its 740:520 aspect ratio ≈ 191. Scaled up
              for the wider desktop container by the same width ratio
              (460 / 390) so it reads at the same relative weight there. */}
          <LogoMark size={variant === 'desktop' ? 225 : 191} color={tokens.text} holeColor={tokens.text} />
        </View>
        <View style={styles.amountRow}>
          <TextInput
            value={amount}
            onChangeText={setAmount}
            keyboardType="numeric"
            placeholder="0"
            placeholderTextColor={tokens.textMuted}
            style={[
              styles.amountInput,
              {
                color: tokens.text,
                // Capped both ends (was: unbounded minWidth, no maxWidth
                // at all) — on a narrow phone, a long-enough amount grew
                // this wider than the screen and pushed the currency
                // suffix off it entirely (Pavel: "the switcher... is
                // actually rendered outside of the screen on mobile").
                // Past the cap the input just scrolls its own text
                // instead of growing further, same as any text field.
                // The explicit maxWidth matters on web specifically: a
                // bare <input> at this font size has its own large
                // browser-default intrinsic width, and minWidth alone
                // only sets a floor — it doesn't stop that intrinsic size
                // from winning and spatially overlapping the currency
                // badge next to it (Pavel's follow-up: the badge was
                // visible but not clickable — something was sitting in
                // front of it).
                minWidth: 60,
                maxWidth: Math.min(Math.max(60, amount.length * 30), 170),
                // flexShrink:1 (was 0) — a last-resort safety net so that
                // even the capped width above still yields to the
                // currency suffix on the narrowest phones, instead of
                // both fighting for space with neither able to shrink.
                flexGrow: 0,
                flexShrink: 1,
                fontVariant: ['tabular-nums'],
              },
            ]}
          />
        {/* Tap cycles CZK → each active currency → back to CZK (Pavel's
            answer: CZK is part of the cycle, one control does everything).
            Styled as a continuation of the number ("1000 CZK") rather than
            a separate button — no border/background chrome, just text
            sitting right after the digits, with a small ▾ as the only hint
            that it's tappable. Only shown once there's something to cycle
            through. zIndex pins it above the amount input explicitly
            (Pavel: "move it to the front so I can actually click it") —
            belt-and-suspenders alongside the maxWidth fix above, since a
            web <input> can otherwise end up eating clicks meant for a
            sibling it visually overlaps even without one being "in front"
            in the ordinary DOM sense. */}
        {activeCurrencies.length > 0 && (
          <Pressable
            onPress={cycleCurrency}
            hitSlop={10}
            style={[styles.currencySuffix, { flexGrow: 0, flexShrink: 0, zIndex: 2 }]}
          >
            <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.semibold, fontSize: 20 }}>
              {currency} <Text style={{ fontSize: 13 }}>▾</Text>
            </Text>
          </Pressable>
        )}
        </View>
      </View>

      {currency !== 'CZK' && (
        <Text style={[styles.czkEquivalent, { color: tokens.textMuted }]}>
          {rateLoading
            ? t('home.rateFetching')
            : rateError
            ? `${t('home.rateErrorPrefix')} ${rateError}`
            : czkEquivalent !== null
            ? `≈ ${czkEquivalent} ${t('common.czk')}`
            : ' '}
        </Text>
      )}

      {/* The event badge (claude/event-based-expenses-v1.md) — shown only
          once at least one event is active, expense-only (an event is a
          bucket of bills, not income). Same tap-to-cycle visual language as
          the currency badge above: plain text + ▾, no button chrome. Stays
          selected across saves (like the category chip, unlike currency)
          since the whole point is that it applies to every bill of a trip
          without re-picking it each time. */}
      {entryType === 'EXPENSE' && activeEvents.length > 0 && (
        <Pressable onPress={cycleEvent} style={styles.eventBadge}>
          <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 13 }}>
            {eventId ? activeEvents.find((e) => e.id === eventId)?.name ?? t('home.eventOff') : t('home.eventOff')}{' '}
            <Text style={{ fontSize: 11 }}>▾</Text>
          </Text>
        </Pressable>
      )}

      {/* Turned off entirely in Settings → Quick amounts if Pavel doesn't
          want the row at all — see profile.quick_amounts_enabled. When on,
          it stays visible even for a foreign currency (these presets are
          CZK-scale numbers added to the field as-is, no conversion), with
          the small label below just to keep that clear. */}
      {quickAmountsEnabled && (
        <>
          <View style={styles.chipRow}>
            {quickAmounts.map((v) => (
              <Pressable
                key={v}
                onPress={() => setAmount((prev) => String((Number(prev) || 0) + v))}
                style={[styles.chip, { backgroundColor: tokens.card }]}
              >
                <Text style={{ color: tokens.text, fontFamily: fontFamily.semibold, fontSize: 13 }}>
                  {v >= 0 ? `+${v}` : `−${Math.abs(v)}`}
                </Text>
              </Pressable>
            ))}
          </View>
          {currency !== 'CZK' && (
            <Text style={[styles.quickAmountsHint, { color: tokens.textMuted }]}>{t('home.quickAmountsInCzk')}</Text>
          )}
        </>
      )}

      {entryType === 'EXPENSE' && (
        // A 3-per-row grid of EQUAL-width chips (Main.dc.html: `grid-
        // template-columns: repeat(3, minmax(0,1fr))`) — not a content-
        // hugging flexWrap row. With chips sized by their own label
        // (Pavel: "the same size pills"), "Food" renders narrow and
        // "Netflix and other internet subscription" stretches almost the
        // full width on its own row; flexBasis: '31%' on every chip forces
        // them all to the same width regardless of label length, with long
        // names truncating instead of blowing out the grid.
        <View style={styles.categoryGrid}>
          {categories.length === 0 ? (
            <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 13 }}>
              {dataLoading ? t('home.settingUpCategories') : t('home.noCategoriesYet')}
            </Text>
          ) : (
            categories.map((cat, index) => {
              const active = activeCategoryId === cat.id;
              return (
                <Pressable
                  key={cat.id}
                  onPress={() => setCategoryId(cat.id)}
                  style={[styles.categoryChip, { backgroundColor: active ? tokens.accent : tokens.card }]}
                >
                  {/* Identity dot, hidden once selected (the solid accent
                      fill already carries "selected") — design refresh
                      (2026-09): wires up tokens.category, a 6-hue palette
                      that was defined but never actually used anywhere,
                      so categories are distinguishable at a glance instead
                      of every chip looking the same until tapped. */}
                  {!active && (
                    <View style={[styles.categoryDot, { backgroundColor: categoryColor(index, tokens) }]} />
                  )}
                  <Text
                    numberOfLines={1}
                    style={{
                      color: active ? tokens.accentText : tokens.text,
                      fontFamily: fontFamily.semibold,
                      fontSize: 13,
                      flexShrink: 1,
                    }}
                  >
                    {cat.name}
                  </Text>
                </Pressable>
              );
            })
          )}
        </View>
      )}

      <TextInput
        value={note}
        onChangeText={setNote}
        placeholder={t('home.notePlaceholder')}
        placeholderTextColor={tokens.textMuted}
        style={[styles.noteInput, { color: tokens.text, borderColor: tokens.border }]}
      />

      <Pressable onPress={() => setShowMoreOptions((v) => !v)} style={styles.splitToggle}>
        <Text style={{ color: tokens.accent, fontFamily: fontFamily.semibold, fontSize: 13 }}>
          {showMoreOptions ? t('home.moreOptionsHide') : t('home.moreOptionsShow')}
        </Text>
      </Pressable>

      {showMoreOptions && (
        <View style={[styles.splitPanel, { backgroundColor: tokens.card, borderColor: tokens.border }]}>
          <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 11.5, marginBottom: 6 }}>
            {t('home.accountLabel')}
          </Text>
          <View style={styles.chipRow}>
            {accounts.map((acc) => {
              const active = activeAccountId === acc.id;
              return (
                <Pressable
                  key={acc.id}
                  onPress={() => setSelectedAccountId(acc.id)}
                  style={[styles.chip, { backgroundColor: active ? tokens.accent : tokens.cardAlt }]}
                >
                  <Text
                    style={{
                      color: active ? tokens.accentText : tokens.text,
                      fontFamily: fontFamily.semibold,
                      fontSize: 12.5,
                    }}
                  >
                    {acc.name}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <Text
            style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 11.5, marginTop: 12, marginBottom: 6 }}
          >
            {t('home.receiptPhotoLabel')}
          </Text>
          {Platform.OS === 'web' ? (
            <>
              {photoPreviewUrl ? (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                  <Image source={{ uri: photoPreviewUrl }} style={styles.photoPreview} />
                  <Pressable onPress={clearPhoto}>
                    <Text style={{ color: tokens.coral, fontFamily: fontFamily.semibold, fontSize: 12.5 }}>
                      {t('common.delete')}
                    </Text>
                  </Pressable>
                </View>
              ) : (
                <Pressable
                  onPress={triggerPhotoPicker}
                  disabled={photoUploading}
                  style={[styles.photoBtn, { backgroundColor: tokens.cardAlt, opacity: photoUploading ? 0.6 : 1 }]}
                >
                  <Text style={{ color: tokens.text, fontFamily: fontFamily.semibold, fontSize: 12.5 }}>
                    {photoUploading ? t('common.saving') : t('home.addPhoto')}
                  </Text>
                </Pressable>
              )}
              {photoError && (
                <Text style={{ color: tokens.coral, fontFamily: fontFamily.medium, fontSize: 11.5, marginTop: 6 }}>
                  {photoError}
                </Text>
              )}
              {createElement('input', {
                ref: fileInputRef,
                type: 'file',
                accept: 'image/*',
                capture: 'environment',
                style: { display: 'none' },
                onChange: handlePhotoChange,
              })}
            </>
          ) : (
            <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 11.5 }}>
              {t('home.photoWebOnly')}
            </Text>
          )}
        </View>
      )}

      {entryType === 'EXPENSE' && (
        <Pressable onPress={() => setSplitEnabled((v) => !v)} style={styles.splitToggle}>
          <Text style={{ color: tokens.accent, fontFamily: fontFamily.semibold, fontSize: 13 }}>
            {splitEnabled ? t('home.splitToggleOff') : t('home.splitToggleOn')}
          </Text>
        </Pressable>
      )}

      {entryType === 'EXPENSE' && splitEnabled && (
        <View style={[styles.splitPanel, { backgroundColor: tokens.card, borderColor: tokens.border }]}>
          {/* Amount + message stay on top (Pavel's request) — the people
              list is at the end, below the evenly-split control. */}
          <TextInput
            value={splitTotalAmount}
            onChangeText={setSplitTotalAmount}
            keyboardType="numeric"
            placeholder={t('home.splitTotalPlaceholder')}
            placeholderTextColor={tokens.textMuted}
            style={[styles.splitInput, { color: tokens.text, borderColor: tokens.border }]}
          />
          <TextInput
            value={splitMessage}
            onChangeText={setSplitMessage}
            placeholder={t('home.messagePlaceholder')}
            placeholderTextColor={tokens.textMuted}
            style={[styles.splitInput, { color: tokens.text, borderColor: tokens.border }]}
          />

          <View style={styles.splitEvenlyRow}>
            <Pressable
              onPress={handleSplitEvenly}
              disabled={splitTotalNumeric <= 0}
              style={[styles.splitAddPersonBtn, { backgroundColor: tokens.cardAlt, opacity: splitTotalNumeric > 0 ? 1 : 0.5 }]}
            >
              <Text style={{ color: tokens.text, fontFamily: fontFamily.semibold, fontSize: 12.5 }}>
                {t('home.splitEvenlyBtn')}
              </Text>
            </Pressable>
            <Text
              style={{
                color: splitRemaining === 0 ? tokens.greenFg : splitRemaining < 0 ? tokens.coral : tokens.textMuted,
                fontFamily: fontFamily.semibold,
                fontSize: 12.5,
              }}
            >
              {splitSum} / {splitTotalNumeric || 0} {t('common.czk')}
              {splitRemaining > 0 ? ` · ${t('home.splitStillMissing')} ${splitRemaining}` : ''}
              {splitRemaining < 0 ? ` · ${t('home.splitOverAllocated')} ${Math.abs(splitRemaining)}` : ''}
            </Text>
          </View>

          {splitPeople.map((p) => (
            <View key={p.id} style={styles.splitPersonRow}>
              <NameAutocompleteInput
                value={p.name}
                onChangeText={(v) => updateSplitPerson(p.id, 'name', v)}
                pastNames={debtHistory.pastNames}
                placeholder={t('home.whoOwesPlaceholder')}
                containerStyle={{ flex: 2 }}
                inputStyle={[styles.splitInput, { color: tokens.text, borderColor: tokens.border }]}
              />
              <TextInput
                value={p.amount}
                onChangeText={(v) => updateSplitPerson(p.id, 'amount', v)}
                keyboardType="numeric"
                placeholder={t('home.howMuchPlaceholder')}
                placeholderTextColor={tokens.textMuted}
                style={[styles.splitInput, { color: tokens.text, borderColor: tokens.border, flex: 1 }]}
              />
              {splitPeople.length > 1 && (
                <Pressable onPress={() => removeSplitPerson(p.id)} hitSlop={8}>
                  <Text style={{ color: tokens.coral, fontFamily: fontFamily.bold, fontSize: 16 }}>×</Text>
                </Pressable>
              )}
            </View>
          ))}
          <Pressable onPress={addSplitPerson} style={[styles.splitAddPersonBtn, { backgroundColor: tokens.cardAlt }]}>
            <Text style={{ color: tokens.text, fontFamily: fontFamily.semibold, fontSize: 12.5 }}>
              {t('home.addPersonBtn')}
            </Text>
          </Pressable>

          <ShareModePicker value={shareMode} onChange={setShareMode} />

          <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 11.5 }}>
            {t('home.splitHint')}
          </Text>
        </View>
      )}

      {errorMsg && (
        <Text style={{ color: tokens.coral, fontFamily: fontFamily.medium, fontSize: 13, textAlign: 'center' }}>
          {errorMsg}
        </Text>
      )}

      {shareLinks.length > 0 && (
        <View style={[styles.shareBox, { backgroundColor: tokens.greenBg }]}>
          <Text style={{ color: tokens.greenFg, fontFamily: fontFamily.semibold, fontSize: 12.5 }}>
            {t('home.shareLinkCreated')}
          </Text>
          {shareLinks.map((link, idx) => (
            <View key={link.link} style={styles.shareLinkRow}>
              <Text style={{ color: tokens.greenFg, fontFamily: fontFamily.semibold, fontSize: 12 }}>{link.name}</Text>
              <Text
                selectable
                numberOfLines={1}
                style={{ color: tokens.greenFg, fontFamily: fontFamily.medium, fontSize: 12 }}
              >
                {link.link}
              </Text>
              <Pressable onPress={() => copyShareLink(idx)} style={[styles.copyBtn, { backgroundColor: tokens.card }]}>
                <Text style={{ color: tokens.text, fontFamily: fontFamily.semibold, fontSize: 12 }}>
                  {copiedLinkIdx === idx ? t('common.copied') : t('common.copyLink')}
                </Text>
              </Pressable>
            </View>
          ))}
        </View>
      )}

      <Pressable
        onPress={() => handleSave()}
        disabled={saving || dataLoading || photoUploading}
        style={[
          styles.saveBtn,
          {
            backgroundColor: tokens.accent,
            opacity: saving || dataLoading || photoUploading ? 0.6 : 1,
            shadowColor: tokens.accent,
          },
        ]}
      >
        <Text style={{ color: tokens.accentText, fontFamily: fontFamily.bold, fontSize: 15 }}>
          {savedFlash ? t('home.savedBtn') : t('home.saveBtn')}
        </Text>
      </Pressable>

      {/* Recent inputs (Settings → Recent inputs) — Pavel: "I am not sure
          what exactly have I already input". Deliberately lightweight: no
          card/border chrome of its own, just a muted label and plain rows,
          so it reads as part of this screen rather than another panel. */}
      {recentInputsEnabled && recentInputs.length > 0 && (
        <View style={styles.recentInputsWrap}>
          <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 11.5 }}>
            {t('home.recentInputsHeading')}
          </Text>
          {recentInputs.map((row) => {
            const categoryName = categories.find((c) => c.id === row.category_id)?.name ?? null;
            const isIncome = row.type === 'INCOME';
            const label = row.note?.trim() || categoryName || (isIncome ? t('home.entryTypeIncome') : t('home.entryTypeExpense'));
            // Only shown as its own tag when it's not already the label
            // above (i.e. there was a note) — Income has no category at
            // all. Otherwise "Food" would just repeat itself on the row.
            const showCategoryTag = !isIncome && categoryName && label !== categoryName;
            return (
              <View key={row.id} style={styles.recentInputRow}>
                <Text numberOfLines={1} style={{ flex: 1, color: tokens.text, fontFamily: fontFamily.medium, fontSize: 12.5 }}>
                  {label}
                </Text>
                {showCategoryTag && (
                  <View style={[styles.recentInputCategoryTag, { backgroundColor: tokens.cardAlt }]}>
                    <Text numberOfLines={1} style={{ color: tokens.textMuted, fontFamily: fontFamily.semibold, fontSize: 10.5 }}>
                      {truncateCategoryName(categoryName, recentInputsCategoryChars)}
                    </Text>
                  </View>
                )}
                <Text style={{ color: isIncome ? tokens.greenFg : tokens.textMuted, fontFamily: fontFamily.semibold, fontSize: 12.5 }}>
                  {isIncome ? '+' : '−'}
                  {row.amount} {t('common.czk')}
                </Text>
                <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 11 }}>
                  {formatShortDate(row.transaction_date, language)}
                </Text>
              </View>
            );
          })}
        </View>
      )}

      <Modal visible={mergeOffer !== null} transparent animationType="fade" onRequestClose={() => setMergeOffer(null)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalCard, { backgroundColor: tokens.bg, borderColor: tokens.border }]}>
            <ScrollView>
              <Text style={{ color: tokens.text, fontFamily: fontFamily.extrabold, fontSize: 16, marginBottom: 10 }}>
                {t('debts.mergeOfferTitle')}
              </Text>
              <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 12, marginBottom: 12 }}>
                {t('debts.mergeOfferIntro')}
              </Text>

              {mergeOffer?.matches.map((m) => {
                const key = m.name.trim().toLowerCase();
                const merging = mergeOffer.chosen.has(key);
                return (
                  <View key={key} style={[styles.mergeOfferRow, { borderColor: tokens.border, backgroundColor: tokens.card }]}>
                    <Text style={{ color: tokens.text, fontFamily: fontFamily.bold, fontSize: 14 }}>{m.name}</Text>
                    <Text style={{ color: tokens.textMuted, fontFamily: fontFamily.medium, fontSize: 12.5 }}>
                      {m.existing.amount} + {m.newAmount} = {m.existing.amount + m.newAmount} {t('common.czk')}
                    </Text>
                    <View style={styles.mergeChoiceRow}>
                      <Pressable
                        onPress={() => setMergeChoice(key, true)}
                        style={[styles.mergeChoiceBtn, { backgroundColor: merging ? tokens.accent : tokens.cardAlt }]}
                      >
                        <Text
                          style={{
                            color: merging ? tokens.accentText : tokens.text,
                            fontFamily: fontFamily.semibold,
                            fontSize: 12.5,
                          }}
                        >
                          {t('debts.mergeOfferMerge')}
                        </Text>
                      </Pressable>
                      <Pressable
                        onPress={() => setMergeChoice(key, false)}
                        style={[styles.mergeChoiceBtn, { backgroundColor: !merging ? tokens.accent : tokens.cardAlt }]}
                      >
                        <Text
                          style={{
                            color: !merging ? tokens.accentText : tokens.text,
                            fontFamily: fontFamily.semibold,
                            fontSize: 12.5,
                          }}
                        >
                          {t('debts.mergeOfferKeepSeparate')}
                        </Text>
                      </Pressable>
                    </View>
                  </View>
                );
              })}

              <View style={styles.modalActions}>
                <Pressable onPress={() => setMergeOffer(null)} style={[styles.modalBtn, { backgroundColor: tokens.card }]}>
                  <Text style={{ color: tokens.text, fontFamily: fontFamily.semibold, fontSize: 14 }}>{t('common.cancel')}</Text>
                </Pressable>
                <Pressable
                  onPress={() => {
                    const offer = mergeOffer;
                    setMergeOffer(null);
                    if (offer) handleSave(offer);
                  }}
                  disabled={saving}
                  style={[styles.modalBtn, { backgroundColor: tokens.accent, opacity: saving ? 0.6 : 1 }]}
                >
                  <Text style={{ color: tokens.accentText, fontFamily: fontFamily.bold, fontSize: 14 }}>
                    {t('debts.mergeOfferContinue')}
                  </Text>
                </Pressable>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { width: '100%', maxWidth: 390, gap: 16 },
  containerDesktop: { maxWidth: 460 },
  typeToggle: { flexDirection: 'row', borderRadius: 14, padding: 3, alignSelf: 'center' },
  typeToggleBtn: { paddingHorizontal: 20, paddingVertical: 8, borderRadius: 11 },
  dateRow: { flexDirection: 'row', alignItems: 'center', gap: 10, justifyContent: 'center' },
  dateShiftBtn: { width: 30, height: 30, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  amountWrap: { position: 'relative' },
  watermarkWrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    opacity: 0.06,
  },
  amountRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'center', gap: 2 },
  amountInput: { fontSize: 48, fontFamily: fontFamily.regular, textAlign: 'center' },
  currencySuffix: { paddingHorizontal: 4, paddingBottom: 12 },
  czkEquivalent: { textAlign: 'center', fontSize: 13, fontFamily: fontFamily.medium, marginTop: -8 },
  eventBadge: { alignSelf: 'center', paddingVertical: 4, paddingHorizontal: 8, marginBottom: 4 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
  quickAmountsHint: { textAlign: 'center', fontSize: 11, fontFamily: fontFamily.medium, marginTop: -4 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 14 },
  // 3-per-row equal-width grid — see the render-time comment above.
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 8,
    paddingVertical: 13,
    borderRadius: 16,
    flexBasis: '31%',
    flexGrow: 0,
    flexShrink: 0,
  },
  categoryDot: { width: 7, height: 7, borderRadius: 4, flexShrink: 0 },
  noteInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  splitToggle: { alignItems: 'center', paddingVertical: 2 },
  splitPanel: { borderWidth: 1, borderRadius: 16, padding: 12, gap: 8 },
  splitInput: { borderWidth: 1, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  splitPersonRow: { flexDirection: 'row', gap: 6, alignItems: 'center' },
  splitEvenlyRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 },
  splitAddPersonBtn: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 7, borderRadius: 11 },
  shareBox: { borderRadius: 16, padding: 12, gap: 8 },
  shareLinkRow: { gap: 4 },
  recentInputsWrap: { gap: 6 },
  recentInputRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  recentInputCategoryTag: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8 },
  copyBtn: { alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 7, borderRadius: 11 },
  saveBtn: {
    paddingVertical: 16,
    borderRadius: 19,
    alignItems: 'center',
    shadowOpacity: 0.28,
    shadowRadius: 16,
    shadowOffset: { width: 0, height: 8 },
    elevation: 4,
  },
  photoBtn: { alignSelf: 'flex-start', paddingHorizontal: 14, paddingVertical: 9, borderRadius: 12 },
  photoPreview: { width: 44, height: 44, borderRadius: 10 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  modalCard: {
    width: '100%',
    maxWidth: 420,
    maxHeight: '85%',
    borderRadius: 20,
    borderWidth: 1,
    padding: 20,
  },
  modalActions: { flexDirection: 'row', gap: 10, marginTop: 20 },
  modalBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, alignItems: 'center' },
  mergeOfferRow: { borderWidth: 1, borderRadius: 14, padding: 12, marginBottom: 10, gap: 6 },
  mergeChoiceRow: { flexDirection: 'row', gap: 8, marginTop: 4 },
  mergeChoiceBtn: { flex: 1, paddingVertical: 8, borderRadius: 11, alignItems: 'center' },
});
